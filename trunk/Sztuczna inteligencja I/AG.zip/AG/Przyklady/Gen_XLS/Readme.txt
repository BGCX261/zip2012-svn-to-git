Genetik V2.0 (June 1999)
Copyright 1998-1999 Noyan Turkkan
================================================

Genetik is a floating-point genetic algorithm to solve optimization problems.
It is a user friendly, menu-driven Excel-97 workbook. Genetik is Freeware and may be freely distributable.

Genetik is authored by:

	Noyan Turkkan
	Universite de Moncton
	School of Engineering
	Moncton, N.B., Canada, E1A 3E9

	E-Mail : turkkan@umoncton.ca
	WWW : http://www.umoncton.ca/turk

================================================