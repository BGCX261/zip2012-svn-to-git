#define POPULATIONSIZE	5000
#define NUMCITIES	32
#define NUMHOOD		32
#define ENLARGE		5
#define	OFFSET		20

typedef struct point {
	int x;
	int y;
} point;

typedef long	         BitType ;
typedef BitType          PersonType[ NUMCITIES ] ;
typedef PersonType       WorldType[ POPULATIONSIZE ] ;
typedef float            PopFitnessType[ POPULATIONSIZE ] ;
typedef int              CityCountType[ NUMCITIES ] ;
typedef point            CityCoordsType[ NUMCITIES ] ;
typedef float            CityDistType[ NUMCITIES ][ NUMCITIES ] ;


void CTspView::drawTour(CDC* pdc)
{
    BitType cityBit ;
    int	currentCity ;
	int lastCity ;
	int i ;
	char tmp[100];
		
	CRect bounds( 0, 0, 100 * ENLARGE, 100  * ENLARGE + OFFSET );
	pdc->FillRect(bounds, CBrush::FromHandle((HBRUSH)GetStockObject(WHITE_BRUSH)));


	if ( maxIterations == numIterations ) {
		sprintf( tmp, "Iteration : %d   Best Tour : %8.2f   Max Iterations %d reached", numIterations, bestFitness, maxIterations ) ;
	}
	else {
		sprintf( tmp, "Iteration : %d   Best Tour : %8.2f", numIterations, bestFitness ) ;
	}


	pdc->TextOut( 10, 5, tmp ) ; 

    lastCity = 0 ;
    cityBit = bestTour[ 0 ];
    for ( currentCity = 0 ; !( cityBit & 1 ) ;	
	currentCity++, ( cityBit >>= 1 ) ) ;
    cityBit = 1 << currentCity ;
	
    for( i = 1 ; i < numCities+1 ; i++ ) {
		pdc->MoveTo( cityCoords[ currentCity ].x * ENLARGE, cityCoords[ currentCity ].y * ENLARGE + OFFSET );
		pdc->LineTo( cityCoords[ lastCity ].x * ENLARGE, cityCoords[ lastCity ].y * ENLARGE + OFFSET );
		cityBit = bestTour[ currentCity ] & ~( 1 << lastCity ) ;
		lastCity = currentCity ;
        for ( currentCity = 0 ; !( cityBit & 1 ) ;
		currentCity++, ( cityBit >>= 1 ) ) ;
    }
}

float CTspView::fitness( PersonType person )
{
    int 	i, lastCity, currentCity ;
    float	fitnessValue ;
    BitType	cityBit ;
	
    fitnessValue = 0 ;
    lastCity = 0 ;
    cityBit = person[ 0 ] ;

    for ( currentCity = 0 ; !( cityBit & 1 ) ;

	currentCity++, ( cityBit >>= 1 ) ) ;
	cityBit = 1 << currentCity ;
				
	for( i = 1 ; i < numCities+1 ; i++ ) {
		fitnessValue += cityDist[ lastCity ][ currentCity ] ;
		cityBit = person[ currentCity ] & ~( 1 << lastCity ) ;
		lastCity = currentCity ;
		for ( currentCity = 0 ; !( cityBit & 1 ) ;
		currentCity++, ( cityBit >>= 1 ) ) ;
	}
				
	return ( fitnessValue ) ;
}

void CTspView::createPopulation( WorldType population, PopFitnessType populationFitness )
{
    int i, j, nextCity, lastCity ;
	
    bestFitness = 10000000 ;
	
    for ( i = 0 ; i < populationSize ; i++ ) {
		lastCity = 0 ;
		for ( j = 0 ; j < numCities ; j++ )
			population[ i ][ j ] = 0 ;
        for ( j = 0 ; j < numCities - 1 ; j++ ) {
			do {
				nextCity = ( rand() % ( numCities - 1 ) ) + 1 ;
			} while (population[ i ][ nextCity ] ) ;
			population[ i ][lastCity] |=  1 << nextCity ;
			population[ i ][nextCity] = 1 << lastCity ;
			lastCity = nextCity ;
		}
        population[ i ][ lastCity ] |= 1 ;
        population[ i ][ 0 ] |= 1 << lastCity ;
		populationFitness[ i ] = fitness( population[ i ] ) ; 
		if ( populationFitness[ i ] < bestFitness )
			bestFitness = populationFitness[ i ] ;
		bestPerson = i ;
    }
}

void CTspView::crossover( PersonType child, PersonType p0, PersonType p1 )
{
    int       	   nextParentPick, i, newCity, newCity1, newCity2, lastCity;
    int		   loops, tempLast ;
    BitType   	   cityBit ;
    CityCountType  cityCount ;
	
    nextParentPick = 0 ;
	
    for ( i = 0; i < numCities; i++ ) {
		child[ i ] = 0 ;
		cityCount[ i ] = 0 ;
    }
	
    for ( i = 0; i < numCities; i++ )
		if ( cityBit = ( p0[ i ] & p1[ i ] ) ) {
			for ( newCity = 0 ; !( cityBit & 1 ) ;
			newCity++, ( cityBit >>= 1 ) ) ;
			child[ i ] =  (1 << newCity) ;
			cityCount[ i ] = -1 ;
			for ( cityBit >>= 1, newCity++ ; (!( cityBit & 1 ) & (newCity < numCities ) ) ;
			newCity++, ( cityBit >>= 1 ) ) ;
			if (newCity < numCities) {
				child[ i ] |=  (1 << newCity) ;
				cityCount[ i ] = 2 ;
			}
		}
		
		i = 0 ;
		tempLast = 0 ;
		lastCity = 0 ;
		newCity = 0 ;
		
		if ( cityCount[ 0 ] != 0 )
			do {
				i++ ;
				cityBit = child[ newCity ] ;
				for ( newCity = 0 ; !( cityBit & 1 ) ; newCity++,
					( cityBit >>= 1 ) ) ;
				if ( newCity == lastCity ) 
					for ( cityBit >>= 1, newCity++ ;
					(!( cityBit & 1 ) & ( newCity < numCities ) );
					newCity++, ( cityBit >>= 1 ) ) ;
					if ( i == numCities ) 
						return ;
					lastCity = tempLast ;
					tempLast = newCity ;
			} while ( cityCount[ newCity ] == 2 ) ;
			
			if ( newCity == 0 )
				cityCount[0] = 1 ;
			else
				cityCount[0] = 2 ;
			
			lastCity = newCity ;
			for ( ; i < numCities - 1 ; i++ ) {
				loops = 0 ;
				do {
					loops++ ;
					if ( loops == 3 )
						break ;
					if ( nextParentPick )
						cityBit = p0[ lastCity ] ;
					else
						cityBit = p1[ lastCity ] ;
					nextParentPick = ~nextParentPick ;

					for ( newCity1 = 0 ; !( cityBit & 1 ) ;
					newCity1++, ( cityBit >>= 1 ) ) ;
					for ( cityBit >>= 1, newCity2 = newCity1 + 1 ;
					!( cityBit & 1 ) ; newCity2++, ( cityBit >>= 1 ) ) ;
					if ( rand() % 2 ) 
						if ( cityCount[ newCity1 ] != 2 )
							newCity = newCity1 ;
						else
							newCity = newCity2 ;
						else
							if ( cityCount[ newCity2 ] != 2 )
								newCity = newCity2 ;
							else
								newCity = newCity1 ;
				} while ( cityCount[ newCity ] == 2 ) ;
				
				cityCount[ lastCity ] = abs( cityCount[ lastCity ] ) + 1 ;
				
				if ( loops == 3 )
					do {
						newCity = ( rand() % ( numCities - 1 ) ) + 1 ;
					} while ( cityCount[ newCity ] == 2 ) ;
					
					child[ lastCity ] |=  (1 << newCity) ;
					child[ newCity ] |= (1 << lastCity) ;
					cityCount[ newCity ] = abs( cityCount[ newCity ] ) + 1 ;
					

					while ( cityCount[ newCity ] == 2 ) {
						i++ ;
						cityBit = child[ newCity ] ;
						tempLast = newCity ;
						for ( newCity = 0 ; !( cityBit & 1 ) ; newCity++, ( cityBit >>= 1 ) ) ;
						if ( newCity == lastCity ) 
							for ( cityBit >>= 1, newCity++ ; (!( cityBit & 1 ) & ( newCity < numCities ) );	newCity++, ( cityBit >>= 1 ) ) ;
							if ( i == numCities )
								return ;
								if ( newCity == 0 ) {
									child[ 0 ] &= ~( 1 << tempLast ) ;
									cityCount[ tempLast ] = 1 ;
									child[ tempLast ] &= ~1 ;
									i-- ; 
									newCity = tempLast ;
									break ;
								}
								lastCity = tempLast ;
					}
					lastCity = newCity ;
			} 
			
			child[ lastCity ] |= 1 ;
			child[ 0 ] |= 1 << lastCity ;
}

void CTspView::makeChildren( WorldType population, PopFitnessType populationFitness )
{
    int	hood[ NUMHOOD ] ;
    int childPos, i, j, best, temp ;
	
    for ( i = 0 ; i < numHood ; i++ )
		hood[ i ] = rand() % populationSize ;
	
    for ( i = 0 ; i < numHood-1 ; i++ ) {
		best = i ; 
		for ( j = i + 1 ; j < numHood ; j++ ) 
			if ( populationFitness[ hood[ j ] ] < populationFitness[ hood[ best ] ] )
				best = j ;
			if ( best != i ) {
				temp = hood[ i ] ;
				hood[ i ] = hood[ best ] ;
				hood[ best ] = temp ;
			}
    }
	

    childPos = hood[ numHood - 1 ] ;
    crossover( (PersonType) population[ childPos ], population[ hood[ 0 ] ], population[ hood[ 1 ] ] ) ;
    populationFitness[ childPos ] = fitness( population[ childPos ] ) ;
    if ( populationFitness[ childPos ] < bestFitness ) {
		bestFitness = populationFitness[ childPos ] ;
		bestPerson = childPos ;
    }
	

    childPos = hood[ numHood - 2 ] ;
    crossover( population[ childPos ], population[ hood[ 1 ] ], population[ hood[ 0 ] ] ) ;
    populationFitness[ childPos ] = fitness( population[ childPos ] ) ;
    if ( populationFitness[ childPos ] < bestFitness ) {
		bestFitness = populationFitness[ childPos ] ;
		bestPerson = childPos ;
    }
}

void CTspView::displayCityList( PersonType person )
{
	for ( int i = 0; i < NUMCITIES; i++ )
	{
		bestTour[i] = person[i];
	}

	RedrawWindow();
}

void CTspView::start()
{
    WorldType 		population ;
    PopFitnessType	populationFitness ;
    float			lastFitness ;
	
	if ( strlen( GetDocument()->m_fileName ) == 0 ) {
		AfxMessageBox("You must open a city list file first.");
		return;
	}

	running = true;

	if ( seed ) {
		srand( seed );
	}
	else {
		srand( (unsigned)time( NULL ) );
	}

	openCityList( GetDocument()->m_fileName );

    numIterations = 0 ;
	
	createPopulation( population, populationFitness ) ;
	
	displayCityList( population[ bestPerson ] ) ;
	
	lastFitness = bestFitness ;
	
	for ( int i = 0; i < maxIterations; i++ ) {
		numIterations++ ;
		makeChildren( population, populationFitness );
		if ( bestFitness < lastFitness ) {
			lastFitness = bestFitness ;
			displayCityList( population[ bestPerson ] ) ;
		}
	}

	RedrawWindow();
}

void CTspView::OnRunStart() 
{
	start();
}

void CTspView::OnSetupParameters() 
{
    CParameters params(this);

    params.m_population = populationSize;
    params.m_tournament = numHood;
    params.m_seed = seed;
	params.m_iterations = maxIterations;

	int result = params.DoModal();
	
    if (result == IDOK)
    {
        populationSize = params.m_population ;
		numHood = params.m_tournament ;
		seed = params.m_seed ;
		maxIterations = params.m_iterations;
    }
}

void CTspView::openCityList( char *fileName ) 
{
    FILE *fp ;
    int i, j ;
	
    if ((fp = fopen(fileName,"r" )) == NULL)
	{
		AfxMessageBox( "Cant open file" );
		return;
	}

	numCities = 0;
	while ( true ) {
		if ( EOF == fscanf(fp, "%d %d", &cityCoords[ numCities ].x, &cityCoords[ numCities ].y) ) {
			break;
		}
		numCities++;
	}

	fclose( fp ) ;

	for ( i = 0 ; i < numCities ; i++ )
		for ( j = 0 ; j < numCities ; j++ )
			cityDist[ i ][ j ] = (float) sqrt( (double) ( pow( (double) ( cityCoords[ i ].x - cityCoords[ j ].x ) , (double) 2 ) + pow( (double) ( cityCoords[ i ].y - cityCoords[ j ].y ) , (double) 2 ))) ;
}